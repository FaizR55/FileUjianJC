package com.juaracoding.maze.animation;

public class Animation {
	
	
	  

}
