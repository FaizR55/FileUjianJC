package com.ujian.akhir;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UjianNativeAkhirApplication {

	public static void main(String[] args) {
		SpringApplication.run(UjianNativeAkhirApplication.class, args);
	}

}
