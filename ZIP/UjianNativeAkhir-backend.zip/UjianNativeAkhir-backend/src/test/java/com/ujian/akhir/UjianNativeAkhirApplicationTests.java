package com.ujian.akhir;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UjianNativeAkhirApplicationTests {

	@Test
	void contextLoads() {
	}

}
