package com.juaracoding.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BelajarMySqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(BelajarMySqlApplication.class, args);
	}

}
