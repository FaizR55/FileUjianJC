export function LoginAction(value,tipe){
    return({type:"SET_LOGIN", inputValue:value,inputType:tipe})
}