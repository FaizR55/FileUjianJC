package com.juaracoding.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceJodohApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiceJodohApplication.class, args);
	}

}
