package com.ujian.relasi.repo;

public interface NilaiRepo {

}
