package com.ujian.relasi.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ujian.relasi.entity.Soal;

public interface SoalRepo extends JpaRepository<Soal, Long> {

}
