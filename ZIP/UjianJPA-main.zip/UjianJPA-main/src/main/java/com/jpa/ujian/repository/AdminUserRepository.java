package com.jpa.ujian.repository;

import org.springframework.data.repository.CrudRepository;

import com.jpa.ujian.entity.AdminUser;

public interface AdminUserRepository extends CrudRepository<AdminUser,  Long>{

}
